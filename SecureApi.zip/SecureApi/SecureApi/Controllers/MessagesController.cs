﻿using Microsoft.AspNetCore.Mvc;
using Microsoft.Extensions.Logging;
using SecureApi.Data;
using SecureApi.Models;
using SecureApi.Services;
using System.Threading.Tasks;

namespace SecureApi.Controllers
{
    [ApiController]
    [Route("[controller]")]
    public class MessagesController : ControllerBase
    {
        private readonly ILogger<MessagesController> _logger;
        private readonly ApplicationDbContext _context;
        private readonly CryptoService _cryptoService;

        public MessagesController(ILogger<MessagesController> logger, ApplicationDbContext context, CryptoService cryptoService)
        {
            _logger = logger;
            _context = context;
            _cryptoService = cryptoService;
        }

        [HttpGet("{id}")]
        public async Task<ActionResult<string>> GetMessage(int id)
        {
            var message = await _context.Messages.FindAsync(id);
            if (message == null)
            {
                _logger.LogWarning("Message with ID: {Id} not found.", id);
                return NotFound();
            }

            var decryptedMessage = _cryptoService.Decrypt(message.EncryptedValue);
            return Ok(decryptedMessage);
        }

        [HttpPost]
        public async Task<ActionResult<Message>> PostMessage([FromBody] string plainText)
        {
            var encryptedMessage = _cryptoService.Encrypt(plainText);
            var message = new Message { EncryptedValue = encryptedMessage };
            _context.Messages.Add(message);
            await _context.SaveChangesAsync();

            return CreatedAtAction(nameof(GetMessage), new { id = message.Id }, message);
        }
    }
}
