﻿using Microsoft.AspNetCore.Mvc;
using SecureApi.Models;

namespace SecureApi.Controllers
{
    public class AuthenticationController : ControllerBase
    {
        private readonly JwtService _jwtService;

        public AuthenticationController(JwtService jwtService)
        {
            _jwtService = jwtService;
        }

        [HttpPost("login")]
        public IActionResult Login(UserLoginDto user)
        {
            var token = _jwtService.GenerateToken();
            return Ok(new { token });
        }
    }

}
